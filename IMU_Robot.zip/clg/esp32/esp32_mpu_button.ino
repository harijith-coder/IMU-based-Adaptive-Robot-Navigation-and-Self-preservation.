#include <MPU6050.h>
#include <Wire.h>

// USB/COM version of your working gesture logic (no ESP-NOW).
const int BUTTON_PIN = 25;

MPU6050 mpu;

float yaw = 0.0f, pitch = 0.0f, roll = 0.0f;
float pitchOffset = 0.0f, rollOffset = 0.0f;
unsigned long lastTime = 0;

void calibrate() {
  int16_t ax, ay, az, gx, gy, gz;
  float sp = 0.0f, sr = 0.0f;
  const int N = 200;

  Serial.println("Calibrating...");
  for (int i = 0; i < N; i++) {
    mpu.getMotion6(&ax, &ay, &az, &gx, &gy, &gz);
    sp += atan2((float)ay, (float)az) * 180.0f / PI;
    sr += atan2((float)-ax, (float)az) * 180.0f / PI;
    delay(5);
  }
  pitchOffset = sp / N;
  rollOffset = sr / N;
  yaw = pitch = roll = 0.0f;
  Serial.println("Calibration done!");
}

void setup() {
  Serial.begin(115200);
  pinMode(BUTTON_PIN, INPUT_PULLUP);
  Wire.begin();

  mpu.initialize();
  delay(100);

  int16_t ax, ay, az, gx, gy, gz;
  mpu.getMotion6(&ax, &ay, &az, &gx, &gy, &gz);
  if (ax == 0 && ay == 0 && az == 0) {
    Serial.println("{\"error\":\"MPU6050 failed\"}");
    while (1) {
      delay(10);
    }
  }
  Serial.println("MPU6050 OK");

  Serial.println("Hold still for calibration...");
  delay(1000);
  calibrate();
  lastTime = millis();
}

void loop() {
  int16_t ax, ay, az, gx, gy, gz;
  mpu.getMotion6(&ax, &ay, &az, &gx, &gy, &gz);

  unsigned long now = millis();
  float dt = (now - lastTime) / 1000.0f;
  if (dt <= 0) dt = 0.001f;
  lastTime = now;

  float gyroX = gx / 131.0f;
  float gyroY = gy / 131.0f;
  float gyroZ = gz / 131.0f;

  float accelPitch = atan2((float)ay, (float)az) * 180.0f / PI;
  float accelRoll = atan2((float)-ax, (float)az) * 180.0f / PI;

  // Complementary filter.
  pitch = 0.96f * (pitch + gyroX * dt) + 0.04f * accelPitch;
  roll = 0.96f * (roll + gyroY * dt) + 0.04f * accelRoll;
  yaw += gyroZ * dt;

  float calibPitch = constrain(pitch - pitchOffset, -90.0f, 90.0f);
  float calibRoll = constrain(roll - rollOffset, -90.0f, 90.0f);
  float calibYaw = constrain(yaw, -90.0f, 90.0f);

  int buttonState = digitalRead(BUTTON_PIN);
  int buttonPressed = (buttonState == LOW) ? 1 : 0;
  int gripperVal = (buttonState == LOW) ? 10 : 90;

  // JSON for FastAPI, keeping old keys for compatibility + new gesture keys.
  Serial.print("{\"button\":");
  Serial.print(buttonPressed);
  Serial.print(",\"accel_x\":");
  Serial.print((float)ax, 3);
  Serial.print(",\"accel_y\":");
  Serial.print((float)ay, 3);
  Serial.print(",\"accel_z\":");
  Serial.print((float)az, 3);
  Serial.print(",\"gyro_x\":");
  Serial.print(gyroX, 3);
  Serial.print(",\"gyro_y\":");
  Serial.print(gyroY, 3);
  Serial.print(",\"gyro_z\":");
  Serial.print(gyroZ, 3);
  Serial.print(",\"temp_c\":0");
  Serial.print(",\"yaw\":");
  Serial.print(calibYaw, 2);
  Serial.print(",\"pitch\":");
  Serial.print(calibPitch, 2);
  Serial.print(",\"roll\":");
  Serial.print(calibRoll, 2);
  Serial.print(",\"gripper\":");
  Serial.print(gripperVal);
  Serial.println("}");

  // 10 values per second.
  delay(100);
}
