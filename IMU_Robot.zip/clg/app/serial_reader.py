import json
import threading
import time
from datetime import datetime, timezone
from collections import deque
from typing import Optional

import serial
from serial import SerialException

from .config import settings
from .models import SensorData


class SerialReader:
    def __init__(self) -> None:
        self._thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()
        self._lock = threading.Lock()
        self._latest: Optional[SensorData] = None
        self._logs: deque[SensorData] = deque(maxlen=250)
        self._connected = False
        self._last_data_monotonic: Optional[float] = None
        self._last_error: Optional[str] = None

    @property
    def connected(self) -> bool:
        with self._lock:
            return self._connected

    def get_latest(self) -> Optional[SensorData]:
        with self._lock:
            return self._latest

    def get_logs(self, limit: int = 100) -> list[SensorData]:
        with self._lock:
            safe_limit = max(1, min(limit, self._logs.maxlen or limit))
            return list(self._logs)[-safe_limit:]

    def get_last_data_age_ms(self) -> Optional[int]:
        with self._lock:
            if self._last_data_monotonic is None:
                return None
            return int((time.monotonic() - self._last_data_monotonic) * 1000)

    def has_recent_data(self, max_age_ms: int = 2000) -> bool:
        age_ms = self.get_last_data_age_ms()
        return age_ms is not None and age_ms <= max_age_ms

    def get_last_error(self) -> Optional[str]:
        with self._lock:
            return self._last_error

    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._stop_event.clear()
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop_event.set()
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=2.0)

    def _set_connected(self, value: bool) -> None:
        with self._lock:
            self._connected = value

    def _set_latest(self, data: SensorData) -> None:
        with self._lock:
            self._latest = data
            self._logs.append(data)
            self._last_data_monotonic = time.monotonic()
            self._last_error = None

    def _set_error(self, message: str) -> None:
        with self._lock:
            self._last_error = message

    def _run(self) -> None:
        while not self._stop_event.is_set():
            try:
                with serial.Serial(
                    port=settings.SERIAL_PORT,
                    baudrate=settings.BAUD_RATE,
                    timeout=settings.SERIAL_TIMEOUT,
                ) as ser:
                    self._set_connected(True)
                    # Give ESP32 time after serial open/reset.
                    time.sleep(2.0)
                    self._read_loop(ser)
            except (SerialException, OSError):
                self._set_connected(False)
                self._set_error("Unable to open serial port. Check COM port or cable.")
                time.sleep(1.0)
            except Exception:
                self._set_connected(False)
                self._set_error("Unexpected serial reader error.")
                time.sleep(1.0)

    def _read_loop(self, ser: serial.Serial) -> None:
        while not self._stop_event.is_set():
            raw_line = ser.readline()
            if not raw_line:
                continue

            try:
                line = raw_line.decode("utf-8", errors="ignore").strip()
                if not line.startswith("{"):
                    continue
                payload = json.loads(line)
                payload["ts"] = datetime.now(timezone.utc).isoformat()
                data = SensorData.model_validate(payload)
                self._set_latest(data)
            except (json.JSONDecodeError, ValueError, TypeError):
                continue
