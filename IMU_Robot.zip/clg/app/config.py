class Settings:
    # Hardcoded serial settings (no env vars required).
    SERIAL_PORT = "COM5"
    BAUD_RATE = 115200
    SERIAL_TIMEOUT = 0.1


settings = Settings()
