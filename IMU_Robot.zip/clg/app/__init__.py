# FastAPI application package for ESP32 serial bridge.
