from datetime import datetime
from pydantic import BaseModel


class SensorData(BaseModel):
    ts: datetime
    button: int
    accel_x: float
    accel_y: float
    accel_z: float
    gyro_x: float
    gyro_y: float
    gyro_z: float
    temp_c: float


class StatusResponse(BaseModel):
    connected: bool
    serial_port: str
    baud_rate: int
    data_received: bool
    last_data_age_ms: int | None = None
    last_error: str | None = None
