import asyncio
import contextlib
from pathlib import Path
from typing import Set

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse
from fastapi.responses import JSONResponse

from .config import settings
from .models import StatusResponse
from .serial_reader import SerialReader

app = FastAPI(title="ESP32 MPU + Button Serial API")
serial_reader = SerialReader()
ws_clients: Set[WebSocket] = set()
stream_task: asyncio.Task | None = None
STATIC_INDEX = Path(__file__).parent / "static" / "index.html"


@app.on_event("startup")
async def startup() -> None:
    global stream_task
    serial_reader.start()
    stream_task = asyncio.create_task(stream_loop())


@app.on_event("shutdown")
async def shutdown() -> None:
    global stream_task
    if stream_task:
        stream_task.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await stream_task
    serial_reader.stop()


@app.get("/")
async def root():
    return FileResponse(
        STATIC_INDEX,
        headers={
            "Cache-Control": "no-store, no-cache, must-revalidate, max-age=0",
            "Pragma": "no-cache",
            "Expires": "0",
        },
    )


@app.get("/status", response_model=StatusResponse)
async def status():
    return StatusResponse(
        connected=serial_reader.connected,
        serial_port=settings.SERIAL_PORT,
        baud_rate=settings.BAUD_RATE,
        data_received=serial_reader.has_recent_data(),
        last_data_age_ms=serial_reader.get_last_data_age_ms(),
        last_error=serial_reader.get_last_error(),
    )


@app.get("/latest")
async def latest():
    data = serial_reader.get_latest()
    if data is None:
        return JSONResponse(
            status_code=404,
            content={"message": "No sensor data yet. Check COM port and ESP32 output."},
        )
    return data.model_dump()


@app.get("/logs")
async def logs(limit: int = 100):
    return [item.model_dump() for item in serial_reader.get_logs(limit)]


@app.websocket("/ws")
async def websocket_endpoint(ws: WebSocket):
    await ws.accept()
    ws_clients.add(ws)
    try:
        while True:
            await ws.receive_text()
    except WebSocketDisconnect:
        ws_clients.discard(ws)
    except Exception:
        ws_clients.discard(ws)


async def stream_loop() -> None:
    last_ts = None
    while True:
        await asyncio.sleep(0.05)
        data = serial_reader.get_latest()
        if data is None:
            continue
        if data.ts == last_ts:
            continue

        last_ts = data.ts
        payload = data.model_dump_json()
        stale_clients = []
        for client in ws_clients:
            try:
                await client.send_text(payload)
            except Exception:
                stale_clients.append(client)

        for client in stale_clients:
            ws_clients.discard(client)
